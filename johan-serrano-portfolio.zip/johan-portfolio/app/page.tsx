"use client"

import { motion } from "framer-motion"
import {
  ArrowRight,
  BookOpen,
  Brain,
  BriefcaseBusiness,
  CheckCircle2,
  Code2,
  Cpu,
  ExternalLink,
  Github,
  GraduationCap,
  Layers3,
  Linkedin,
  Mail,
  Menu,
  Rocket,
  Sparkles,
  TerminalSquare,
  Users,
  Workflow,
  X,
} from "lucide-react"
import { useState } from "react"

const navItems = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Education", href: "#education" },
  { label: "Skills", href: "#skills" },
  { label: "Projects", href: "#projects" },
  { label: "Notes", href: "#notes" },
  { label: "Dashboard", href: "#dashboard" },
  { label: "Contact", href: "#contact" },
]

const aboutCards = [
  {
    title: "Practical Builder",
    description: "I focus on building small but useful projects that solve clear problems and help me improve with real practice.",
    icon: Rocket,
  },
  {
    title: "Fast Learner",
    description: "I study by creating, breaking things, fixing errors and documenting what I learn along the way.",
    icon: Brain,
  },
  {
    title: "Problem Solver",
    description: "I like turning messy ideas into structured systems, simple interfaces and working software.",
    icon: Workflow,
  },
]

const educationTimeline = [
  {
    title: "Programming Student",
    detail: "Focused on software fundamentals, logic, structured thinking and practical projects.",
  },
  {
    title: "Python Fundamentals",
    detail: "Console apps, JSON persistence, dates, menus, reports and clean program structure.",
  },
  {
    title: "Web Development Basics",
    detail: "HTML, CSS, responsive layouts, UI structure and one-page web experiences.",
  },
  {
    title: "Git & GitHub",
    detail: "Version control, repositories, branches and project documentation.",
  },
  {
    title: "Continuous Learning",
    detail: "Currently improving React, Next.js, APIs, SQL and production-ready web practices.",
  },
]

const skills = [
  {
    category: "Core",
    icon: TerminalSquare,
    items: ["Python", "Git", "GitHub", "Problem Solving"],
  },
  {
    category: "Web",
    icon: Code2,
    items: ["HTML", "CSS", "JavaScript Basics", "Tailwind CSS"],
  },
  {
    category: "Learning",
    icon: Cpu,
    items: ["SQL", "APIs", "React", "Next.js"],
  },
  {
    category: "Soft Skills",
    icon: Users,
    items: ["Adaptability", "Creativity", "Teamwork", "Discipline in Progress"],
  },
]

const projects = [
  {
    name: "Daily Expense Tracker",
    description:
      "Python application to register daily, weekly and monthly expenses with JSON persistence, dates, menus and organized reports.",
    stack: ["Python", "JSON", "Datetime", "Tabulate"],
    status: "Completed",
  },
  {
    name: "SoftEstimate",
    description:
      "Responsive web project designed to estimate software costs through clean screens, selection cards and a structured summary flow.",
    stack: ["HTML", "CSS", "Responsive UI"],
    status: "Learning Project",
  },
  {
    name: "MUNDIAL Football Probability App",
    description:
      "Sports analysis app concept for football match probabilities, news, injuries, lineups, weather, stadium context and predictions.",
    stack: ["Python", "FastAPI", "Data Packs", "Analysis"],
    status: "In Progress",
  },
  {
    name: "Campus Ecommerce",
    description:
      "Academic ecommerce practice focused on product structure, layout logic, interface organization and web fundamentals.",
    stack: ["HTML", "CSS", "Git"],
    status: "Learning Project",
  },
  {
    name: "Campus Cinema",
    description:
      "Practice project for managing cinema-style content, layouts, cards and user-facing information architecture.",
    stack: ["HTML", "CSS", "JavaScript Basics"],
    status: "Learning Project",
  },
  {
    name: "GangaTech Product Scout",
    description:
      "Digital product research system concept for scouting trends, validating opportunities and organizing ecommerce ideas.",
    stack: ["Research", "Systems", "Marketing", "Automation"],
    status: "Concept",
  },
]

const notes = [
  {
    title: "What I learned building my first Python expense tracker",
    category: "Python",
    readTime: "4 min read",
    description: "Lessons from handling dates, JSON files, menus and report generation in a real beginner project.",
  },
  {
    title: "Why Git matters for beginner developers",
    category: "GitHub",
    readTime: "3 min read",
    description: "A simple explanation of how version control helps me work cleaner and protect progress.",
  },
  {
    title: "How I approach problem solving as a programming student",
    category: "Learning",
    readTime: "5 min read",
    description: "My process for breaking problems into smaller steps, testing assumptions and improving solutions.",
  },
  {
    title: "My roadmap to becoming a junior developer",
    category: "Career",
    readTime: "6 min read",
    description: "A practical roadmap around Python, web development, React, SQL, projects and interview preparation.",
  },
]

const dashboardStats = [
  { label: "Projects Built", value: "6+", detail: "Academic and personal" },
  { label: "Technologies Practiced", value: "8+", detail: "Python, Web, Git, SQL" },
  { label: "Current Focus", value: "React", detail: "Next.js and UI systems" },
  { label: "Status", value: "Open", detail: "Junior opportunities" },
]

const progressItems = [
  { label: "Python", value: 78 },
  { label: "HTML / CSS", value: 74 },
  { label: "Git & GitHub", value: 66 },
  { label: "React / Next.js", value: 42 },
]

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0 },
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1 text-sm font-medium text-slate-600 shadow-sm">
      <Sparkles className="h-3.5 w-3.5 text-indigo-500" />
      {children}
    </div>
  )
}

function SectionHeading({ eyebrow, title, description }: { eyebrow: string; title: string; description: string }) {
  return (
    <motion.div
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, amount: 0.25 }}
      transition={{ duration: 0.5 }}
      variants={fadeUp}
      className="mx-auto mb-12 max-w-3xl text-center"
    >
      <SectionLabel>{eyebrow}</SectionLabel>
      <h2 className="text-3xl font-semibold tracking-tight text-slate-950 sm:text-4xl">{title}</h2>
      <p className="mt-4 text-base leading-7 text-slate-600 sm:text-lg">{description}</p>
    </motion.div>
  )
}

function StatusBadge({ status }: { status: string }) {
  const statusClass =
    status === "Completed"
      ? "border-emerald-200 bg-emerald-50 text-emerald-700"
      : status === "In Progress"
        ? "border-indigo-200 bg-indigo-50 text-indigo-700"
        : status === "Concept"
          ? "border-amber-200 bg-amber-50 text-amber-700"
          : "border-slate-200 bg-slate-50 text-slate-700"

  return <span className={`rounded-full border px-2.5 py-1 text-xs font-medium ${statusClass}`}>{status}</span>
}

export default function PortfolioPage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const currentYear = new Date().getFullYear()

  return (
    <div className="min-h-screen bg-white text-slate-950">
      <header className="fixed inset-x-0 top-0 z-50 border-b border-slate-200/70 bg-white/80 backdrop-blur-xl">
        <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 lg:px-8" aria-label="Main navigation">
          <a href="#home" className="group flex items-center gap-3" aria-label="Go to home section">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-slate-950 text-sm font-semibold text-white shadow-soft transition-transform group-hover:-translate-y-0.5">
              JS
            </div>
            <div>
              <p className="text-sm font-semibold tracking-tight">Johan Serrano</p>
              <p className="text-xs text-slate-500">Junior Developer in Progress</p>
            </div>
          </a>

          <div className="hidden items-center gap-1 lg:flex">
            {navItems.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className="rounded-full px-3 py-2 text-sm font-medium text-slate-600 transition hover:bg-slate-100 hover:text-slate-950"
              >
                {item.label}
              </a>
            ))}
          </div>

          <div className="hidden items-center gap-3 lg:flex">
            <a
              href="#projects"
              className="rounded-full border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-700 transition hover:border-slate-300 hover:bg-slate-50"
            >
              View Projects
            </a>
            <a
              href="#contact"
              className="inline-flex items-center gap-2 rounded-full bg-slate-950 px-4 py-2 text-sm font-semibold text-white transition hover:-translate-y-0.5 hover:bg-slate-800"
            >
              Contact Me <ArrowRight className="h-4 w-4" />
            </a>
          </div>

          <button
            type="button"
            className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-slate-200 lg:hidden"
            aria-label="Toggle navigation menu"
            aria-expanded={isMenuOpen}
            onClick={() => setIsMenuOpen((current) => !current)}
          >
            {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </nav>

        {isMenuOpen && (
          <div className="border-t border-slate-200 bg-white px-5 py-4 lg:hidden">
            <div className="grid gap-2">
              {navItems.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  className="rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.label}
                </a>
              ))}
            </div>
          </div>
        )}
      </header>

      <main>
        <section id="home" className="relative overflow-hidden px-5 pt-32 lg:px-8 lg:pt-40">
          <div className="absolute left-1/2 top-0 -z-10 h-[520px] w-[920px] -translate-x-1/2 rounded-full bg-gradient-to-br from-indigo-100 via-slate-50 to-white blur-3xl" />
          <div className="mx-auto grid max-w-7xl items-center gap-12 lg:grid-cols-[1.05fr_0.95fr]">
            <motion.div initial="hidden" animate="visible" transition={{ duration: 0.6 }} variants={fadeUp}>
              <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1.5 text-sm font-medium text-slate-600 shadow-sm">
                <GraduationCap className="h-4 w-4 text-indigo-500" />
                Programming Student · Junior Developer in Progress
              </div>
              <h1 className="max-w-4xl text-5xl font-semibold tracking-tight text-slate-950 sm:text-6xl lg:text-7xl">
                Building practical software while learning to become a better developer.
              </h1>
              <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-600">
                I’m Johan Serrano, a programming student focused on Python, web development, digital products and real-world problem solving.
              </p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <a
                  href="#projects"
                  className="inline-flex items-center justify-center gap-2 rounded-full bg-slate-950 px-6 py-3 text-sm font-semibold text-white shadow-soft transition hover:-translate-y-0.5 hover:bg-slate-800"
                >
                  View Projects <ArrowRight className="h-4 w-4" />
                </a>
                <a
                  href="#contact"
                  className="inline-flex items-center justify-center gap-2 rounded-full border border-slate-200 bg-white px-6 py-3 text-sm font-semibold text-slate-700 transition hover:-translate-y-0.5 hover:border-slate-300 hover:bg-slate-50"
                >
                  Contact Me <Mail className="h-4 w-4" />
                </a>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: 0.7, delay: 0.15 }}
              className="relative"
            >
              <div className="absolute -inset-6 -z-10 rounded-[2rem] bg-gradient-to-br from-indigo-100 to-slate-100 blur-2xl" />
              <div className="rounded-[2rem] border border-slate-200 bg-white p-5 shadow-soft">
                <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                  <div>
                    <p className="text-sm font-semibold text-slate-950">Learning Dashboard</p>
                    <p className="text-xs text-slate-500">Updated through real practice</p>
                  </div>
                  <div className="flex gap-1.5">
                    <span className="h-3 w-3 rounded-full bg-slate-200" />
                    <span className="h-3 w-3 rounded-full bg-slate-300" />
                    <span className="h-3 w-3 rounded-full bg-slate-400" />
                  </div>
                </div>

                <div className="mt-5 grid gap-4 sm:grid-cols-2">
                  {[
                    { label: "Python", value: "Core logic", icon: TerminalSquare },
                    { label: "Web Dev", value: "HTML · CSS · JS", icon: Code2 },
                    { label: "GitHub", value: "Version control", icon: Github },
                    { label: "Learning", value: "Every day", icon: BookOpen },
                  ].map((item) => {
                    const Icon = item.icon
                    return (
                      <div key={item.label} className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                        <Icon className="mb-4 h-5 w-5 text-indigo-500" />
                        <p className="text-sm font-semibold text-slate-950">{item.label}</p>
                        <p className="mt-1 text-xs text-slate-500">{item.value}</p>
                      </div>
                    )
                  })}
                </div>

                <div className="mt-5 rounded-2xl border border-slate-200 p-4">
                  <div className="mb-3 flex items-center justify-between">
                    <span className="text-sm font-medium text-slate-700">Current growth</span>
                    <span className="text-sm font-semibold text-slate-950">68%</span>
                  </div>
                  <div className="h-2 rounded-full bg-slate-100">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: "68%" }}
                      transition={{ duration: 1, delay: 0.4 }}
                      className="h-2 rounded-full bg-slate-950"
                    />
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        <section id="about" className="px-5 py-24 lg:px-8">
          <div className="mx-auto max-w-7xl">
            <SectionHeading
              eyebrow="About"
              title="A developer profile built on practice, not fake seniority."
              description="This portfolio is designed to communicate progress, discipline and potential without pretending to be something it is not. The brand is honest: student today, stronger developer every project."
            />

            <div className="grid gap-6 lg:grid-cols-[0.95fr_1.05fr]">
              <motion.div
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, amount: 0.25 }}
                transition={{ duration: 0.5 }}
                variants={fadeUp}
                className="rounded-[2rem] border border-slate-200 bg-slate-950 p-8 text-white shadow-soft"
              >
                <p className="text-sm font-semibold text-indigo-200">Personal positioning</p>
                <h3 className="mt-4 text-3xl font-semibold tracking-tight">I build to learn, and I learn to build better.</h3>
                <p className="mt-5 leading-7 text-slate-300">
                  I am in the training stage, focused on turning study topics into practical software: Python tools, web interfaces, structured projects and digital systems. My goal is to become a reliable junior developer by creating projects that prove consistency, curiosity and execution.
                </p>
              </motion.div>

              <div className="grid gap-6 sm:grid-cols-3 lg:grid-cols-1">
                {aboutCards.map((card, index) => {
                  const Icon = card.icon
                  return (
                    <motion.div
                      key={card.title}
                      initial="hidden"
                      whileInView="visible"
                      viewport={{ once: true, amount: 0.25 }}
                      transition={{ duration: 0.5, delay: index * 0.08 }}
                      variants={fadeUp}
                      className="rounded-[1.5rem] border border-slate-200 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-soft"
                    >
                      <Icon className="h-6 w-6 text-indigo-500" />
                      <h3 className="mt-4 text-lg font-semibold text-slate-950">{card.title}</h3>
                      <p className="mt-2 text-sm leading-6 text-slate-600">{card.description}</p>
                    </motion.div>
                  )
                })}
              </div>
            </div>
          </div>
        </section>

        <section id="education" className="bg-slate-50 px-5 py-24 lg:px-8">
          <div className="mx-auto max-w-7xl">
            <SectionHeading
              eyebrow="Education"
              title="A learning path focused on useful developer fundamentals."
              description="The timeline shows the base skills behind the projects: logic, Python, web structure, version control and continuous improvement."
            />

            <div className="mx-auto max-w-4xl">
              {educationTimeline.map((item, index) => (
                <motion.div
                  key={item.title}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true, amount: 0.25 }}
                  transition={{ duration: 0.5, delay: index * 0.05 }}
                  variants={fadeUp}
                  className="relative grid gap-4 border-l border-slate-200 pb-10 pl-8 last:pb-0"
                >
                  <div className="absolute -left-3 top-0 flex h-6 w-6 items-center justify-center rounded-full border border-slate-200 bg-white">
                    <div className="h-2.5 w-2.5 rounded-full bg-indigo-500" />
                  </div>
                  <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                    <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                      <h3 className="text-lg font-semibold text-slate-950">{item.title}</h3>
                      <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-slate-600">Step {index + 1}</span>
                    </div>
                    <p className="mt-3 leading-7 text-slate-600">{item.detail}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section id="skills" className="px-5 py-24 lg:px-8">
          <div className="mx-auto max-w-7xl">
            <SectionHeading
              eyebrow="Skills"
              title="Tech stack organized around what I can build and what I am learning."
              description="The goal is not to list every technology possible. It is to show a realistic stack, current strengths and the next skills being developed."
            />

            <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">
              {skills.map((group, index) => {
                const Icon = group.icon
                return (
                  <motion.div
                    key={group.category}
                    initial="hidden"
                    whileInView="visible"
                    viewport={{ once: true, amount: 0.25 }}
                    transition={{ duration: 0.5, delay: index * 0.08 }}
                    variants={fadeUp}
                    className="rounded-[1.75rem] border border-slate-200 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-soft"
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-600">
                        <Icon className="h-5 w-5" />
                      </div>
                      <h3 className="text-lg font-semibold text-slate-950">{group.category}</h3>
                    </div>
                    <div className="mt-6 grid gap-3">
                      {group.items.map((item) => (
                        <div key={item} className="flex items-center gap-3 rounded-2xl border border-slate-100 bg-slate-50 px-4 py-3">
                          <CheckCircle2 className="h-4 w-4 text-indigo-500" />
                          <span className="text-sm font-medium text-slate-700">{item}</span>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )
              })}
            </div>
          </div>
        </section>

        <section id="projects" className="bg-slate-950 px-5 py-24 text-white lg:px-8">
          <div className="mx-auto max-w-7xl">
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.25 }}
              transition={{ duration: 0.5 }}
              variants={fadeUp}
              className="mx-auto mb-12 max-w-3xl text-center"
            >
              <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-sm font-medium text-slate-300">
                <Layers3 className="h-3.5 w-3.5 text-indigo-300" />
                Projects
              </div>
              <h2 className="text-3xl font-semibold tracking-tight sm:text-4xl">Project gallery with real learning value.</h2>
              <p className="mt-4 text-base leading-7 text-slate-300 sm:text-lg">
                Each project exists to prove a different skill: logic, persistence, interface design, research, systems thinking or data-driven analysis.
              </p>
            </motion.div>

            <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
              {projects.map((project, index) => (
                <motion.article
                  key={project.name}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true, amount: 0.2 }}
                  transition={{ duration: 0.5, delay: index * 0.05 }}
                  variants={fadeUp}
                  className="group rounded-[1.75rem] border border-white/10 bg-white/[0.03] p-6 transition hover:-translate-y-1 hover:bg-white/[0.06]"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/10 text-indigo-200">
                      <BriefcaseBusiness className="h-5 w-5" />
                    </div>
                    <StatusBadge status={project.status} />
                  </div>
                  <h3 className="mt-6 text-xl font-semibold tracking-tight text-white">{project.name}</h3>
                  <p className="mt-3 min-h-24 text-sm leading-6 text-slate-300">{project.description}</p>
                  <div className="mt-5 flex flex-wrap gap-2">
                    {project.stack.map((tech) => (
                      <span key={tech} className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs font-medium text-slate-300">
                        {tech}
                      </span>
                    ))}
                  </div>
                  <div className="mt-6 flex gap-3">
                    <a
                      href="#"
                      className="inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 text-sm font-semibold text-slate-950 transition hover:bg-slate-200"
                    >
                      View Details <ExternalLink className="h-4 w-4" />
                    </a>
                    <a
                      href="https://github.com/johanserrano200613"
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-2 rounded-full border border-white/10 px-4 py-2 text-sm font-semibold text-white transition hover:bg-white/10"
                    >
                      GitHub <Github className="h-4 w-4" />
                    </a>
                  </div>
                </motion.article>
              ))}
            </div>
          </div>
        </section>

        <section id="notes" className="px-5 py-24 lg:px-8">
          <div className="mx-auto max-w-7xl">
            <SectionHeading
              eyebrow="Study Notes"
              title="Learning in public through notes and technical reflections."
              description="This section reinforces the profile as someone who studies, documents and turns lessons into practical developer growth."
            />

            <div className="grid gap-6 md:grid-cols-2">
              {notes.map((note, index) => (
                <motion.article
                  key={note.title}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true, amount: 0.25 }}
                  transition={{ duration: 0.5, delay: index * 0.06 }}
                  variants={fadeUp}
                  className="rounded-[1.75rem] border border-slate-200 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-soft"
                >
                  <div className="mb-5 flex items-center justify-between gap-4">
                    <span className="rounded-full bg-indigo-50 px-3 py-1 text-xs font-semibold text-indigo-700">{note.category}</span>
                    <span className="text-xs font-medium text-slate-500">{note.readTime}</span>
                  </div>
                  <h3 className="text-xl font-semibold tracking-tight text-slate-950">{note.title}</h3>
                  <p className="mt-3 leading-7 text-slate-600">{note.description}</p>
                </motion.article>
              ))}
            </div>
          </div>
        </section>

        <section id="dashboard" className="bg-slate-50 px-5 py-24 lg:px-8">
          <div className="mx-auto max-w-7xl">
            <SectionHeading
              eyebrow="Dashboard"
              title="A simple activity snapshot for a developer in formation."
              description="This simulated dashboard communicates consistency, focus and professional direction without depending on external APIs."
            />

            <div className="grid gap-6 lg:grid-cols-[1fr_1.15fr]">
              <motion.div
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, amount: 0.25 }}
                transition={{ duration: 0.5 }}
                variants={fadeUp}
                className="grid gap-4 sm:grid-cols-2"
              >
                {dashboardStats.map((stat) => (
                  <div key={stat.label} className="rounded-[1.5rem] border border-slate-200 bg-white p-6 shadow-sm">
                    <p className="text-sm font-medium text-slate-500">{stat.label}</p>
                    <p className="mt-3 text-4xl font-semibold tracking-tight text-slate-950">{stat.value}</p>
                    <p className="mt-2 text-sm text-slate-600">{stat.detail}</p>
                  </div>
                ))}
              </motion.div>

              <motion.div
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, amount: 0.25 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                variants={fadeUp}
                className="rounded-[2rem] border border-slate-200 bg-white p-8 shadow-soft"
              >
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <h3 className="text-2xl font-semibold tracking-tight text-slate-950">Skill progress</h3>
                    <p className="mt-2 text-sm text-slate-600">Estimated progress based on current practice and project exposure.</p>
                  </div>
                  <div className="rounded-full border border-slate-200 px-3 py-1 text-xs font-semibold text-slate-600">No external API</div>
                </div>

                <div className="mt-8 grid gap-6">
                  {progressItems.map((item, index) => (
                    <div key={item.label}>
                      <div className="mb-2 flex items-center justify-between">
                        <span className="text-sm font-semibold text-slate-700">{item.label}</span>
                        <span className="text-sm font-semibold text-slate-950">{item.value}%</span>
                      </div>
                      <div className="h-2.5 rounded-full bg-slate-100">
                        <motion.div
                          initial={{ width: 0 }}
                          whileInView={{ width: `${item.value}%` }}
                          viewport={{ once: true }}
                          transition={{ duration: 0.8, delay: index * 0.08 }}
                          className="h-2.5 rounded-full bg-slate-950"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        <section id="contact" className="px-5 py-24 lg:px-8">
          <div className="mx-auto grid max-w-7xl gap-8 lg:grid-cols-[0.9fr_1.1fr]">
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.25 }}
              transition={{ duration: 0.5 }}
              variants={fadeUp}
              className="rounded-[2rem] bg-slate-950 p-8 text-white shadow-soft"
            >
              <SectionLabel>Contact</SectionLabel>
              <h2 className="mt-2 text-4xl font-semibold tracking-tight">Let’s build something useful.</h2>
              <p className="mt-5 leading-7 text-slate-300">
                I am open to junior opportunities, collaborations, practical projects and conversations around software, web development and digital products.
              </p>
              <div className="mt-8 grid gap-3">
                <a href="mailto:resetogaming779@gmail.com" className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/5 p-4 text-sm font-medium text-slate-200 transition hover:bg-white/10">
                  <Mail className="h-5 w-5 text-indigo-200" />
                  resetogaming779@gmail.com
                </a>
                <a href="https://github.com/johanserrano200613" target="_blank" rel="noreferrer" className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/5 p-4 text-sm font-medium text-slate-200 transition hover:bg-white/10">
                  <Github className="h-5 w-5 text-indigo-200" />
                  GitHub Profile
                </a>
                <a href="#" className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/5 p-4 text-sm font-medium text-slate-200 transition hover:bg-white/10">
                  <Linkedin className="h-5 w-5 text-indigo-200" />
                  LinkedIn Profile
                </a>
              </div>
            </motion.div>

            <motion.form
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.25 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              variants={fadeUp}
              className="rounded-[2rem] border border-slate-200 bg-white p-8 shadow-soft"
            >
              <div className="grid gap-5">
                <label className="grid gap-2">
                  <span className="text-sm font-semibold text-slate-700">Name</span>
                  <input
                    type="text"
                    name="name"
                    placeholder="Your name"
                    className="rounded-2xl border border-slate-200 px-4 py-3 text-sm outline-none transition placeholder:text-slate-400 focus:border-slate-400 focus:ring-4 focus:ring-slate-100"
                  />
                </label>
                <label className="grid gap-2">
                  <span className="text-sm font-semibold text-slate-700">Email</span>
                  <input
                    type="email"
                    name="email"
                    placeholder="your@email.com"
                    className="rounded-2xl border border-slate-200 px-4 py-3 text-sm outline-none transition placeholder:text-slate-400 focus:border-slate-400 focus:ring-4 focus:ring-slate-100"
                  />
                </label>
                <label className="grid gap-2">
                  <span className="text-sm font-semibold text-slate-700">Message</span>
                  <textarea
                    name="message"
                    rows={6}
                    placeholder="Tell me about the opportunity or project..."
                    className="resize-none rounded-2xl border border-slate-200 px-4 py-3 text-sm outline-none transition placeholder:text-slate-400 focus:border-slate-400 focus:ring-4 focus:ring-slate-100"
                  />
                </label>
                <button
                  type="button"
                  className="inline-flex items-center justify-center gap-2 rounded-full bg-slate-950 px-6 py-3 text-sm font-semibold text-white transition hover:-translate-y-0.5 hover:bg-slate-800"
                >
                  Send Message <ArrowRight className="h-4 w-4" />
                </button>
                <p className="text-xs leading-5 text-slate-500">
                  This is a visual form. Connect it to a backend, email service or form provider when deploying.
                </p>
              </div>
            </motion.form>
          </div>
        </section>
      </main>

      <footer className="border-t border-slate-200 px-5 py-8 lg:px-8">
        <div className="mx-auto flex max-w-7xl flex-col gap-4 text-sm text-slate-500 sm:flex-row sm:items-center sm:justify-between">
          <p>
            © {currentYear} Johan Serrano. Junior Developer in Progress.
          </p>
          <div className="flex gap-4">
            <a href="#home" className="hover:text-slate-950">Home</a>
            <a href="#projects" className="hover:text-slate-950">Projects</a>
            <a href="#contact" className="hover:text-slate-950">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  )
}
