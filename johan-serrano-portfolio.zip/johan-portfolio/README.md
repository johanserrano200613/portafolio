# Johan Serrano Portfolio

Minimal one-page portfolio built with Next.js, Tailwind CSS, Framer Motion and Lucide React.

## Run locally

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

## Main file

The main portfolio is in:

```bash
app/page.tsx
```

Edit the placeholder links for GitHub, LinkedIn and email when needed.
